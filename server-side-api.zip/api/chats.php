<?php
	include("connection.php");
    if(isset($_GET["acc"])){
        $chats=array();
        $accountno=mysqli_real_escape_string($conn,$_GET["acc"]);
        $statement="SELECT DISTINCT fldfrom,fldto FROM tblchats WHERE fldfrom='$accountno' or fldto='$accountno'";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        
        while($record=mysqli_fetch_assoc($query)){
            $temp=array();
            if($accountno==$record["fldto"]){
                $temp["accountno"]=$record["fldfrom"];
            }else{
                $temp["accountno"]=$record["fldto"];
            }
            $statement="SELECT * FROM tblclients WHERE fldaccountno='$record[fldto]' or fldaccountno='$record[fldfrom]'";
            $client_query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
            while($client=mysqli_fetch_assoc($client_query)){
                if($client["fldaccountno"]==$temp["accountno"]){
                    $temp['phoneno']="$client[fldphoneno]";
                    $temp["fullname"]="$client[fldfirstname] $client[fldsurname]";
                }
            }
            $chats[]=$temp;
        }
        $chats=(array)array_unique($chats, SORT_REGULAR);
        $chats=array_values($chats);
        echo json_encode($chats);
    }
?>