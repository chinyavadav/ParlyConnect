<?php
    include("connection.php");
    $parliamentarians=array();
    if(isset($_GET["id"])){
        $id=mysqli_real_escape_string($conn,$_GET["id"]);
    	$statement="SELECT * FROM tblmembers";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        while($record=mysqli_fetch_assoc($query)){          
            $parliamentarians[]=$record;
        }
    }
    echo json_encode($parliamentarians);   
?>