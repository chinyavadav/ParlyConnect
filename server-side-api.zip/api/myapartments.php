<?php
    include("connection.php");
    $apartments=array();
    if(isset($_GET["acc"])){
        $accountno=mysqli_real_escape_string($conn,$_GET["acc"]);
        if(isset($_GET["app"]) && isset($_GET["delete"])){
            $apartmentno=mysqli_real_escape_string($conn,$_GET["app"]);
            $statement="DELETE FROM tblapartment_tenants WHERE fldapartmentid='$apartmentno' and fldaccountno='$accountno'";
            $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
            $apartments["response"]="success";
        }else{
        	$statement="SELECT * FROM tblapartment_tenants JOIN tblapartments ON tblapartment_tenants.fldapartmentid=tblapartments.fldapartmentid WHERE tblapartment_tenants.fldaccountno='$accountno'";
            $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
            while($record=mysqli_fetch_assoc($query)){          
                $apartments[]=$record;
            }
        }
    }
    echo json_encode($apartments);   
?>