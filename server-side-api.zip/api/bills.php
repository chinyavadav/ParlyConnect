<?php
include("connection.php");
$bills=array();
$statement="SELECT * FROM tblbills";
$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
while($record=mysqli_fetch_assoc($query)){          
	$bills[]=$record;
}
echo json_encode($bills);   
?>