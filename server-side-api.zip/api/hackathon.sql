-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 28, 2019 at 06:39 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hackathon`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblapartments`
--

CREATE TABLE `tblapartments` (
  `fldapartmentid` varchar(8) NOT NULL,
  `fldlandlord` varchar(8) DEFAULT NULL,
  `fldaddress` varchar(200) DEFAULT NULL,
  `fldtownship` varchar(50) DEFAULT NULL,
  `flddistrict` varchar(50) DEFAULT NULL,
  `fldlat` varchar(20) DEFAULT NULL,
  `fldlng` varchar(20) DEFAULT NULL,
  `fldapartmenttype` varchar(20) DEFAULT NULL,
  `fldrooms` int(11) DEFAULT NULL,
  `fldbedrooms` int(11) DEFAULT NULL,
  `fldbathrooms` int(11) DEFAULT NULL,
  `fldkitchens` int(11) DEFAULT NULL,
  `fldlounges` int(11) NOT NULL,
  `fldcomment` varchar(200) DEFAULT NULL,
  `fldstatus` varchar(20) DEFAULT NULL,
  `flddatetime` varchar(20) DEFAULT NULL,
  `fldcostrange` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblapartments`
--

INSERT INTO `tblapartments` (`fldapartmentid`, `fldlandlord`, `fldaddress`, `fldtownship`, `flddistrict`, `fldlat`, `fldlng`, `fldapartmenttype`, `fldrooms`, `fldbedrooms`, `fldbathrooms`, `fldkitchens`, `fldlounges`, `fldcomment`, `fldstatus`, `flddatetime`, `fldcostrange`) VALUES
('A193011U', 'C192345N', '4312 Nehanda Road', 'Adelaide Park', 'Gweru', '', '', 'Shared', 12, 4, 2, 2, 1, '', 'Vacant', '2019-05-15 12:30:46', '<$100'),
('A196556W', 'C195179V', '312 Nehosho Road', 'Nehosho', 'Gweru', '', '', 'Shared', 10, 2, 2, 1, 1, '', 'Vacant', '2019-05-15 12:36:00', '$100-$199'),
('A198832Q', 'C192345N', '4365 Mutage Street', 'Senga', 'Gweru', '', '', 'Full Rental', 5, 2, 1, 1, 1, '', 'Vacant', '2019-05-15 12:32:22', '$500-$999'),
('A199844O', 'C192345N', '56 Senga Road', 'Adelaide Park', 'Gweru', '', '', 'Shared', 12, 6, 2, 2, 1, '', 'Vacant', '2019-05-15 12:33:59', '$100-$199');

-- --------------------------------------------------------

--
-- Table structure for table `tblapartment_tenants`
--

CREATE TABLE `tblapartment_tenants` (
  `fldapartmentid` varchar(8) NOT NULL,
  `fldaccountno` varchar(8) NOT NULL,
  `flddatetime` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblapartment_tenants`
--

INSERT INTO `tblapartment_tenants` (`fldapartmentid`, `fldaccountno`, `flddatetime`) VALUES
('A196556W', 'C192345N', '2019-05-17');

-- --------------------------------------------------------

--
-- Table structure for table `tblbackups`
--

CREATE TABLE `tblbackups` (
  `fldbackupid` int(11) NOT NULL,
  `flddatetime` varchar(20) DEFAULT NULL,
  `flddoneby` varchar(64) DEFAULT NULL,
  `fldfilename` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbackups`
--

INSERT INTO `tblbackups` (`fldbackupid`, `flddatetime`, `flddoneby`, `fldfilename`) VALUES
(1, '2019-05-11 07:07:14', 'admin@charmze.co.zw', '1557551234.sql'),
(2, '2019-05-12 18:55:33', 'admin@charmze.co.zw', '1557680133.sql'),
(3, '2019-05-13 15:53:32', 'admin@charmze.co.zw', '1557755612.sql');

-- --------------------------------------------------------

--
-- Table structure for table `tblbills`
--

CREATE TABLE `tblbills` (
  `fldbillid` int(11) NOT NULL,
  `fldname` varchar(200) DEFAULT NULL,
  `fldsummary` varchar(2000) DEFAULT NULL,
  `fldagree` int(11) DEFAULT NULL,
  `flddisagree` int(11) DEFAULT NULL,
  `fldstatus` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbills`
--

INSERT INTO `tblbills` (`fldbillid`, `fldname`, `fldsummary`, `fldagree`, `flddisagree`, `fldstatus`) VALUES
(1, 'GWANDA STATE UNIVERSITY BILL H.B 9, 2015', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Passed'),
(2, 'MONEY LAUNDERING AND PROCEEDS OF CRIME AMENDMENT BILL, H.B. 4, 2019', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Passed'),
(3, 'CORONER\'S OFFICE BILL, H.B. 5, 2019', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Passed'),
(4, 'FREEDOM OF INFORMATION BILL, H.B. 6, 2019', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Pending'),
(5, 'MARRIAGES BILL[ H.B. 7, 2019.]', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Pending'),
(6, 'APPROPRIATION BILL 2019 HB 12', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Passed'),
(7, 'COMPANIES AND OTHER BUSINESS ENTITIES BILL', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Passed'),
(8, 'MONEY LAUNDERING AND PROCEEDS OF CRIME (AMENDMENT) BILL', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Passed'),
(9, 'PUBLIC HEALTH BILL 2017', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Passed'),
(10, 'PUBLIC ENTITIES CORPORATE GOVERNANCE BILL, H.B 5, 2017,', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Passed'),
(11, 'NATIONAL PEACE & RECONCILIATION BILL 2017', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Passed'),
(12, 'APPROPRIATION BILL HB 14 2016', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Passed'),
(13, 'CONSTITUTION OF ZIMBABWE AMENDMENT BILL NO 01', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Passed'),
(14, 'MOVABLE PROPERTY SECURITY ILN\'IERESTS BILL', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Pending'),
(15, 'RESERVE BANK AMMENDMENT BILL', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Pending'),
(16, 'PUBLIC PROCUREMENT AND DISPOSLA BILL H. B. 5, 2016]', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Passed'),
(17, 'ZEP--RE (MEMBERSHIP OF ZIMBABWE AND BRA CI-I HB. 9, 2016]', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Passed'),
(18, 'NATIONAL COMPETITIVENESS COMMISSION BILL', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Passed'),
(19, 'DEEDS REGISTRY AMENDMENT BILL HB 3 OF 2016', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Passed'),
(20, 'JUDICIARY LAWS AMENDMENT HB 4 OF 2016', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Passed'),
(21, 'MINES AND MINERALS AMENDMENT BILL FINAL H.B. 19, 2015.', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Passed'),
(22, 'LAND COMMISSION BILL H.B. 2, 2016', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Passed'),
(23, 'LOCAL GOVERNMENT LAWS AMENDMENT BILL H.B. 1, 2016', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Passed'),
(24, 'PAN AFRICAN MINERALS UNIVERSITY OF SCIENCE AND TECHNOLOGY BILL, 2015', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Pending'),
(25, 'MINERALS EXPLORATION MARKETING CORPORATION BILL', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Pending'),
(26, 'MANICALAND STATE UNIVERSITY H.B 8 , 2015', 'To establish the Gwanda State University; and to provide for matters connected therewith or incidental thereto.', 0, 0, 'Passed');

-- --------------------------------------------------------

--
-- Table structure for table `tblbookings`
--

CREATE TABLE `tblbookings` (
  `fldapartmentid` varchar(8) NOT NULL,
  `fldaccountno` varchar(8) NOT NULL,
  `flddatetime` varchar(20) DEFAULT NULL,
  `fldcomment` varchar(200) DEFAULT NULL,
  `fldstatus` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblchats`
--

CREATE TABLE `tblchats` (
  `fldmessageid` int(11) NOT NULL,
  `fldfrom` varchar(8) DEFAULT NULL,
  `fldto` varchar(8) DEFAULT NULL,
  `fldmessage` varchar(1000) DEFAULT NULL,
  `fldtimestamp` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblchats`
--

INSERT INTO `tblchats` (`fldmessageid`, `fldfrom`, `fldto`, `fldmessage`, `fldtimestamp`) VALUES
(1, 'C195179V', 'C192345N', 'Hie', '1557928627000'),
(2, 'C195179V', 'C192345N', 'Halo', '1557929339000'),
(3, 'C195179V', 'C192345N', 'halo', '1557929354000'),
(4, 'C192345N', 'C195179V', 'how are you', '1557931518000'),
(5, 'C195179V', 'C192345N', 'Ok', '1557932437000'),
(6, 'C192345N', 'C195179V', 'eg', '1557933331000'),
(7, 'C192345N', 'C195179V', '?', '1557933448000'),
(8, 'C195179V', 'C192345N', 'dfjhgjhgjfd', '1558013913000'),
(9, 'C195179V', 'C192345N', 'jsdfsdjfhvictor', '1558098728000'),
(10, 'C195179V', 'C192345N', 'ok', '1558098850000'),
(11, 'C195179V', 'C192345N', 'bg', '1558099009000'),
(12, 'C195179V', 'C192345N', 'Gghg', '1558102693000'),
(13, 'C192345N', 'C195179V', 'Ghhj', '1558451005000');

-- --------------------------------------------------------

--
-- Table structure for table `tblclients`
--

CREATE TABLE `tblclients` (
  `fldaccountno` varchar(8) NOT NULL,
  `fldaccounttype` varchar(200) NOT NULL,
  `fldphoneno` varchar(10) NOT NULL,
  `fldfirstname` varchar(50) DEFAULT NULL,
  `fldsurname` varchar(30) DEFAULT NULL,
  `fldsex` varchar(10) DEFAULT NULL,
  `fldconstutuency` varchar(200) NOT NULL,
  `fldstatus` varchar(20) DEFAULT NULL,
  `fldpassword` varchar(32) DEFAULT NULL,
  `flddate` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblclients`
--

INSERT INTO `tblclients` (`fldaccountno`, `fldaccounttype`, `fldphoneno`, `fldfirstname`, `fldsurname`, `fldsex`, `fldconstutuency`, `fldstatus`, `fldpassword`, `flddate`) VALUES
('C198525R', '', '0782135087', 'Victor', 'Chinyavada', 'Male', 'Mbare', 'Active', '5f4dcc3b5aa765d61d8327deb882cf99', '2019-07-27');

-- --------------------------------------------------------

--
-- Table structure for table `tblcommittees`
--

CREATE TABLE `tblcommittees` (
  `fldid` int(11) NOT NULL,
  `fldname` varchar(10000) DEFAULT NULL,
  `fldtime` varchar(200) NOT NULL,
  `fldvenue` varchar(200) NOT NULL,
  `fldclerk` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcommittees`
--

INSERT INTO `tblcommittees` (`fldid`, `fldname`, `fldtime`, `fldvenue`, `fldclerk`) VALUES
(1, 'Transport and Infrastructure Development', 'Monday 1000 hrs', 'Committee Room No. 1', 'Ms. Macheza'),
(2, 'Public Accounts', 'Monday 1000hrs', 'Committee Room No. 2', 'Mr Daniel'),
(3, 'Environment, Water, Tourism and Hospitality Industry', 'Monday 1000hrs', 'Committee Room No. 4', 'Ms Nyawo');

-- --------------------------------------------------------

--
-- Table structure for table `tblmembers`
--

CREATE TABLE `tblmembers` (
  `fldid` int(11) NOT NULL,
  `fldname` varchar(100) DEFAULT NULL,
  `fldsex` varchar(100) DEFAULT NULL,
  `fldconstituency` varchar(100) DEFAULT NULL,
  `fldparty` varchar(100) DEFAULT NULL,
  `fldphone` varchar(100) DEFAULT NULL,
  `fldemail` varchar(100) DEFAULT NULL,
  `fldpicture` varchar(300) DEFAULT NULL,
  `fldpassword` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblmembers`
--

INSERT INTO `tblmembers` (`fldid`, `fldname`, `fldsex`, `fldconstituency`, `fldparty`, `fldphone`, `fldemail`, `fldpicture`, `fldpassword`) VALUES
(2, 'Bushu Bramwell', 'M', 'Shamva South', 'ZANU PF', '778251526', 'bramwellbushu@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/c1034feeb8e544b33d1fc604d40ae043_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(3, 'Chamisa Starman', 'M ', 'Mbare', 'MDC-A', '712758441', 'schamisa@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/b61427359683b4e30ca6f8df2dd5e601_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(4, 'Chanda Gorden', 'M', 'Gokwe Sesame', 'ZANU PF', '779516426', '', 'https://www.parlzim.gov.zw/media/k2/items/cache/e7a7db55704b10f5842044165d3d8c04_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(5, 'Chidamba Sydney', 'M', 'Mazowe Central', 'ZANU PF', '772390062', '', 'https://www.parlzim.gov.zw/media/k2/items/cache/fd7174f310491325c2615b39cde60bb7_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(6, 'Chimbaira Goodrich', 'M', 'Zengeza East', 'MDC-A', '772859404', 'g.chimbaira@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/523b526c8bf5a1718afbf5e37e598b68_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(7, 'Chimina Livingstone', 'M', 'Chiwundura', 'MDC-A', '73277268', 'liviechimina@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/a5cc3f97de32caace96cca0a797115a7_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(8, 'Chinhamo Masango Precious', 'F ', 'Mhangura', 'ZANU PF', '773839808', 'pmassey67@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/d59d2c2b289c88ea3883733aab2dc8de_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(9, 'Chinotimba Joseph', 'M', 'Buhera South', 'ZANU PF', '712869055', 'chinotimbaj@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/89601bda48977e8139a1ddcf09fa1fd3_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(10, 'Chitura Lucia', 'F', 'PR', 'ZANU PF', '777693604', 'chituralucia@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/4a1e0346ad8b97a6503d7ab1c9c8680f_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(11, 'Dube Patrick', 'M', 'Gwanda Central', 'MDC-A', '773672301', '', 'https://www.parlzim.gov.zw/media/k2/items/cache/87f9b7a0e220ce7e8d7355ffedb40745_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(12, 'Houghton John Roland', 'M', 'Kariba', 'MDC-A', '772565163', 'jhoughton@chitake.net', 'https://www.parlzim.gov.zw/media/k2/items/cache/eea4518f1429f185be7035ff9652eb50_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(13, 'Jaja Joyce', 'F', 'PR', 'MDC-A', '772287921', 'Joycejaja722@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/2ce85df04f10d845d088abd07283ce75_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(14, 'Kabozo Stephen', 'M', 'Mt Darwin South', 'ZANU PF', '773752599', '', 'https://www.parlzim.gov.zw/media/k2/items/cache/9f7d409dff686d15d6aec4c50a9e8ef5_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(15, 'Kankuni Winnie', 'F ', 'Sunningdale', 'MDC-A', '774823487', '', 'https://www.parlzim.gov.zw/media/k2/items/cache/bf2a6da712b4888886bfd89e48898f6f_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(16, 'Kapuya Freddy', 'M', 'Mhondoro Mubaira', 'ZANU PF', '772680804', 'Wackdnie2@yahoo.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/814c5fa8cc246f42c53a91bddf076dee_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(17, 'Khumalo Sibangumuzi Sixtone', 'M', 'Tsholotsho North', 'ZANU PF', '712808040', 'sibskhumalo@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/8f3e3c616d91a831ec66aed0a5288dd7_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(18, 'Kwaramba Goodluck', 'F', 'PR', 'ZANU PF', '777560325', 'kwarambagood@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/355a2f5e4acecd91104a7e7c5553f2cc_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(19, 'Labode Mafoko Ruth', 'F', 'PR', 'MDC-A', '775567508', 'ruthlabode58@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/9492d34aeaff0c196b67b67d4c27f695_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(20, 'Maboyi Ruth Mavhungu', 'F', 'Beitbridge West', 'ZANU PF', '776090246', '', 'https://www.parlzim.gov.zw/media/k2/items/cache/6bfebd1c3ab25d1cf8939c071f7a71e9_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(21, 'Machingura Raymore', 'M', 'Chipinge Central', 'ZANU PF', '772551715', 'Machingura.ra3@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/72754b70fe6beee440ef38686ca1c17b_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(22, 'Mago Nyaradzai', 'F', 'PR', 'MDC-A', '773440866', 'nyariemago@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/8fbb0968bd0c2a321a1bbb050e3eaac1_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(23, 'Mahlangu Sichelesile', 'F', 'Pumula', 'MDC-A', '776727724', '', 'https://www.parlzim.gov.zw/media/k2/items/cache/98e0cdd4e0bdb1a2d8e1cded7f0b007c_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(24, 'Majaya Bacillia', 'F', 'PR', 'MDC-A', '774512671', 'bacilliamajaya@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/3d74814c4f24d20971395971f72ccc46_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(25, 'Makonya Joyce', 'F', 'PR', 'MDC-A', '773768632', 'joymakonya@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/9d232fe10819aa1647f0aee610508837_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(26, 'Mamombe Joanah', 'F', 'Harare West', 'MDC-A', '773519914', 'jojomamombe@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/54b4716a3dc0cd733b26e61ebb10e28e_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(27, 'Mangora Brightness', 'F', 'PR', 'MDC-A', '773363613', 'bmangora@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/ec6d7c55be779f1a762db0dddd79069d_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(28, 'Maphosa Lindiwe', 'F', 'PR', 'MDC-A', '773243902', 'maphosalindiwe20@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/4da167b47b42cedc21eda925acac1c94_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(29, 'Markham Allan Norman', 'M', 'Harare North', 'MDC-A', '772278460', 'rusty@adas.co.zw', 'https://www.parlzim.gov.zw/media/k2/items/cache/b233d972ada3f6b911297ef40b012c8a_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(30, 'Masenda Ngoni Takundwa', 'M', 'Hurungwe Central', 'ZANU PF', '714006660', '', 'https://www.parlzim.gov.zw/media/k2/items/cache/83d805430a76a62d95bd944b328ed4da_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(31, 'Masuku Phelela', 'M', 'Nketa', 'MDC-A', '775166705', 'masukuphelela@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/106f632d5c181b8a1e4525bcbb909092_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(32, 'Mataruse Peter', 'M', 'Chinhoyi', 'MDC-A', '712407566', 'dr.mataruse@yahoo.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/9ce385bc6280a235db23faa4db5e78be_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(33, 'Matewu Caston', 'M', 'Marondera Central', 'MDC-A', '776367881', 'cmatewu1@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/a45484ba179cef1dbc1529b14ac4e4b2_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(34, 'Mathe Stars', 'F', 'Nkayi South', 'ZANU PF', '772322656', 'starsmathe@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/9d6360f0276684abf50235473fcfe3e8_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(35, 'Matsikenyere Nokuthula', 'F', 'Chimanimanni West', 'ZANU PF', '772476956', 'nokumatsix@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/97e01ec200ffa55bfa3bc0ba309a83fa_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(36, 'Mavenyengwa Robson', 'M', 'Zaka North', 'ZANU PF', '772835156', 'mavenyengwar@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/e4277b24b080d69d4b50c2dc533bc4bc_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(37, 'Mavetera Tatenda Annastacia', 'F', 'PR', 'ZANU PF', '772934234', 'tatendamvtr@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/20b5dc5f887e6fe6c5015df5dbc4373e_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(38, 'Mawite Dumezweni', 'M', 'ZvishabaneNgezi', 'ZANU PF', '712442536', 'mawited77@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/9e742c00b6831ce5ef1ecffa26793251_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(39, 'Mhere Edmond', 'M', 'Masvingo Central', 'ZANU PF', '773897337', 'Edmondmhere96@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/cee8d15e533fe0d998594b417925cd58_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(40, 'Mkandla Molly', 'F', 'PR', 'ZANU PF', '712766165', 'mkandlamolly@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/66121bc28c9d23f8a6cd26cc53117b58_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(41, 'Moyo Peter', 'M', 'Southerton ', 'MDC-A', '772469139', 'petermuparuri@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/515f73ff95891609f3052d596e50e868_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(42, 'Moyo Richard', 'M', 'Umguza', 'ZANU PF', '778137527', '', 'https://www.parlzim.gov.zw/media/k2/items/cache/bdd855fb7775fd36266a0900a249e256_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(43, 'Mpame Cuthbert', 'M', 'Zvishabane Runde', 'ZANU PF', '776464974', 'cuthbertmpame@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/3f014ec0c76dec9472ea85e089b96881_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(44, 'Mpofu Mtokozisi Manoki', 'M', 'Silobela', 'ZANU PF', '773744483', '', 'https://www.parlzim.gov.zw/media/k2/items/cache/f346e026708bd9bfa4c258b6d0707a5d_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(45, 'Mpofu Rossy', 'F', 'PR', 'ZANU PF', '716009934', '', 'https://www.parlzim.gov.zw/media/k2/items/cache/9ade5171eb1f9a75bc254ef5710cc832_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(46, 'Mudyiwa Magna', 'F', 'Mudzi West', 'ZANU PF', '772888288', 'magnamudyiwa@yahoo.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/889c4ff35cfe1f2875be51f99e27a090_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(47, 'Mugweni Campion Takura', 'M', 'Mazowe North', 'ZANU PF', '719118247', 'campionmugweni75@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/78cd6fbcf6fb2ba93c813682fd618a74_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(48, 'Ndiweni Dought', 'M', 'Hurungwe Central', 'ZANU PF', '772239105', 'doughtndiweni@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/4f424d273207076187fcaaac234fe4fd_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(49, 'Ndlovu Nomathemba', 'F', 'PR', 'MDC-A', '773876435', 'nomathendlo@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/41ba7f77c770a5c3a2110354f4d18992_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(50, 'Nguluvhe Albert', 'M', 'Beitbridge East', 'ZANU PF', '773047913', 'nguluvhea@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/bbef2b7b679c4a3f6307636a786d3b79_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(51, 'Ngwenya Stephen', 'M', 'GokweGumunyu', 'ZANU PF', '772881361', 'stephngwenya@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/b438a68b469c31d6e2a1609d1c36634c_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(52, 'Nyabani Tendai', 'M', 'Rushinga', 'ZANU PF', '772207384', 'tendainyabani@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/91f509849f6467bb518faf710f229661_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(53, 'Nyamudeza Sibonile', 'M', 'Chipinge West', 'MDC-A', '774018069', 'sibonilenyamudeza@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/99d2a86172cee13c9812af5a1accf7cc_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(54, 'Nyashanu Mathew', 'M', 'Buhera Central', 'ZANU PF', '772276082', 'salmaholdings@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/96ab633c1a7119e2ddbcd479b4b75068_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(55, 'Nyathi Ronald Robson', 'M', 'Shurugwi North', 'ZANU PF', '712421150', 'rennyathi@yahoo.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/9161a26aaf1549661c201609c94dcbff_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(56, 'Nyoni Ilos', 'M', 'Bulawayo East ', 'MDC-A', '716984537', 'inyoni835@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/21f17c9e863ce68047046a2d88bbdae5_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(57, 'Raidza Marko', 'M', 'Mberengwa East', 'ZANU PF', '719991188', 'mraidza@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/aa60bf3dba7b06bf9bbc06ae7996d676_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(58, 'Sansole Tose Wesley', 'M', 'Hwange East', 'MDC-A', '772249138', 'twsansole@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/d9640fd356a2fdd2860810454b9f9005_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(59, 'Sibanda Omega', 'M', 'Vungu', 'ZANU PF', '772332504', 'locdistributors@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/e53e70365d51081c22c1d8f970c43d59_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(60, 'Sikhala Job', 'M', 'Zengeza West', 'MDC-A', '773756658', 'jobsikhalalaw@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/c10018f3843934a44da6fc5208ffef5b_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(61, 'Singo Lisa', 'F', 'PR', 'ZANU PF', '772623648', 'lissas338@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/46e21e7be60567c4b9b2ca9018587f88_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(62, 'Sithole James', 'M', 'Makokoba', 'MDC-A', '773385879', '', 'https://www.parlzim.gov.zw/media/k2/items/cache/159410b2d8aaed37af98fd73a83bd77e_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(63, 'Sithole Spare', 'M', 'Insiza South', 'ZANU PF', '712786867', '', 'https://www.parlzim.gov.zw/media/k2/items/cache/ef60364f224305d0b9f19741ec3fdf58_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(64, 'Toffa Jasmine', 'F', 'PR', 'MDC-A', '782745859', 'jasminetoffa@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/919acbd93a09198eef55d141863c0dbb_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(65, 'Tongofa Mathias', 'M', 'Chivi North', 'ZANU PF', '772616428', 'mathstogofa@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/615033493d84468fb165029946f0c44e_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(66, 'Tshuma Dingilizwe', 'M', 'Emakhandeni-Entumbane', 'MDC-A', '778693688', 'tshumads@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/df4cd83a7afb42155e20ead9e0eed213_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(67, 'Tsunga Regai', 'M', 'Mutasa South', 'MDC-A', '777286338', 'regaitsunga@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/ba0dcc459ba28dad37cba99e09a9c5b8_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99'),
(68, 'Watson Nicola Jane', 'F', 'Bulawayo Central ', 'MDC-A', '772284592', 'nicbrowncil@gmail.com', 'https://www.parlzim.gov.zw/media/k2/items/cache/6872c3893ac5058b505224cac9dd8089_S.jpg', '5f4dcc3b5aa765d61d8327deb882cf99');

-- --------------------------------------------------------

--
-- Table structure for table `tblpetitions`
--

CREATE TABLE `tblpetitions` (
  `fldid` int(11) NOT NULL,
  `fldaddress` varchar(10000) DEFAULT NULL,
  `fldbody` varchar(1000) DEFAULT NULL,
  `fldrequest` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpetitions`
--

INSERT INTO `tblpetitions` (`fldid`, `fldaddress`, `fldbody`, `fldrequest`) VALUES
(1, 'The Parliament of Zimbabwe', 'SIGNATURES OF\r\nOTHER PETITIONERS\r\n	 If required, attach\r\nadditional pages for\r\nsignatures\r\n	 The request must\r\nappear at the top of\r\neach additional page\r\n	 Other information such\r\nas postal addresses\r\nmay also be provided\r\nbut they are not\r\nrequired. As such,\r\npetitions seeking this\r\ninformation should note\r\na voluntary field\r\n	 Signatures on the\r\nreverse of a petition,\r\nor on a blank page,\r\nwill not be counted', 'Requesting for Investigations into the matter.');

-- --------------------------------------------------------

--
-- Table structure for table `tblprofiles`
--

CREATE TABLE `tblprofiles` (
  `fldaccountno` varchar(8) NOT NULL,
  `fldmaritalstatus` varchar(20) DEFAULT NULL,
  `fldcohabitors` int(11) DEFAULT NULL,
  `fldother` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `fldemail` varchar(64) NOT NULL,
  `fldfirstname` varchar(20) DEFAULT NULL,
  `fldlastname` varchar(20) DEFAULT NULL,
  `fldpassword` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`fldemail`, `fldfirstname`, `fldlastname`, `fldpassword`) VALUES
('admin@charmze.co.zw', 'John', 'Moyo', '5f4dcc3b5aa765d61d8327deb882cf99'),
('sales@charmze.co.zw', 'Bill', 'Gates', '5f4dcc3b5aa765d61d8327deb882cf99');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblapartments`
--
ALTER TABLE `tblapartments`
  ADD PRIMARY KEY (`fldapartmentid`);

--
-- Indexes for table `tblapartment_tenants`
--
ALTER TABLE `tblapartment_tenants`
  ADD PRIMARY KEY (`fldapartmentid`,`fldaccountno`);

--
-- Indexes for table `tblbackups`
--
ALTER TABLE `tblbackups`
  ADD PRIMARY KEY (`fldbackupid`);

--
-- Indexes for table `tblbills`
--
ALTER TABLE `tblbills`
  ADD PRIMARY KEY (`fldbillid`);

--
-- Indexes for table `tblbookings`
--
ALTER TABLE `tblbookings`
  ADD PRIMARY KEY (`fldapartmentid`,`fldaccountno`);

--
-- Indexes for table `tblchats`
--
ALTER TABLE `tblchats`
  ADD PRIMARY KEY (`fldmessageid`);

--
-- Indexes for table `tblclients`
--
ALTER TABLE `tblclients`
  ADD PRIMARY KEY (`fldaccountno`),
  ADD UNIQUE KEY `fldphoneno` (`fldphoneno`);

--
-- Indexes for table `tblcommittees`
--
ALTER TABLE `tblcommittees`
  ADD PRIMARY KEY (`fldid`);

--
-- Indexes for table `tblmembers`
--
ALTER TABLE `tblmembers`
  ADD PRIMARY KEY (`fldid`);

--
-- Indexes for table `tblpetitions`
--
ALTER TABLE `tblpetitions`
  ADD PRIMARY KEY (`fldid`);

--
-- Indexes for table `tblprofiles`
--
ALTER TABLE `tblprofiles`
  ADD PRIMARY KEY (`fldaccountno`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`fldemail`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblbackups`
--
ALTER TABLE `tblbackups`
  MODIFY `fldbackupid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblbills`
--
ALTER TABLE `tblbills`
  MODIFY `fldbillid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `tblchats`
--
ALTER TABLE `tblchats`
  MODIFY `fldmessageid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tblcommittees`
--
ALTER TABLE `tblcommittees`
  MODIFY `fldid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblmembers`
--
ALTER TABLE `tblmembers`
  MODIFY `fldid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `tblpetitions`
--
ALTER TABLE `tblpetitions`
  MODIFY `fldid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
