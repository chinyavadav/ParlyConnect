<?php
    include("connection.php");
    $bookings=array();
    if(isset($_GET["acc"])){
        $accountno=mysqli_real_escape_string($conn,$_GET["acc"]);
        if(isset($_GET["app"]) && isset($_GET["delete"])){
            $apartmentno=mysqli_real_escape_string($conn,$_GET["app"]);
            $statement="DELETE FROM tblbookings WHERE fldapartmentid='$apartmentno' and fldaccountno='$accountno'";
            $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
            $bookings["response"]="success";
        }else{
            $statement="SELECT tblbookings.fldapartmentid,tblbookings.fldstatus,tblbookings.flddatetime,tblapartments.flddistrict,tblapartments.fldtownship,tblapartments.fldaddress FROM tblbookings JOIN tblapartments ON tblbookings.fldapartmentid=tblapartments.fldapartmentid WHERE fldaccountno='$accountno'";
            $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
            while($record=mysqli_fetch_assoc($query)){          
                $bookings[]=$record;
            }
        }
    }
    echo json_encode($bookings);   
?>